var width = 700; // The width of the svg is a global variable
var height = 700; // The height of the svg is a global variable

var fdata; // The formatted data is a global variable
var rendered_year = 0;
var playing = false;

// Setting the Y axis
var yAxis = d3.scaleLinear()
	.domain([0, 90])
	.range([height, 0])

// Setting the X axis
var xAxis = d3.scaleLog()
	.base(10)
	.range([0, width])
	.domain([142, 190000])




var area = d3.scaleLinear()
	.range([10, 70])
	.domain([2000, 1400000000]);

// TODO Ordinal scale for colors for example: d3.scaleOrdinal(d3.schemePastel1)
var continentColor = d3.scaleOrdinal(d3.schemePastel1);


var svg = d3.select("#svg_chart")
	.attr("width", width)
	.attr("height", height)
	.style("background", "aqua")
	.style("stroke", "black");

//.append("svg")


svg.append("g").attr("transform", "translate(20,20 )")
       .call(d3.axisLeft()
                   .scale(yAxis));
svg.append("text")             
      .attr("transform","translate(50,400)rotate(-90)")
      .text("Life Exp(years)").attr("font-size", "20px");




svg.append("g").attr("transform", "translate(20,680 )")
       .call(d3.axisBottom()
                   .scale(xAxis).tickFormat(d3.format(".0s")).ticks(3)); 



svg.append("text")             
      .attr("transform",
            "translate(375,670)")
      .text("Income(In U.S Dollars)").attr("font-size", "20px");



svg.append("text")             
      .attr("transform",
            "translate(590,580)")
      .text("Asia").attr("font-size", "20px");

svg.append("text")             
      .attr("transform",
            "translate(590,605)")
      .text("Americas").attr("font-size", "20px");

svg.append("text")             
      .attr("transform",
            "translate(590,630)")
      .text("Europe").attr("font-size", "20px");

svg.append("text")             
      .attr("transform",
            "translate(590,655)")
      .text("Africa").attr("font-size", "20px");

           

                              


// Reading the input data
d3.json("data.json").then(function (data) {

	// Console log the original data
	console.log(data);

	// Cleanup data
	fdata = data.map(function (year_data) {
		// retain the countries for which both the income and life_exp is specified
		return year_data["countries"].filter(function (country) {
			var existing_data = (country.income && country.life_exp);
			return existing_data
		}).map(function (country) {
			// convert income and life_exp into integers (everything read from a file defaults to an string)
			country.income = +country.income;
			country.life_exp = +country.life_exp;
			return country;
		})
	});

	// Console log the formatted data
	console.log(fdata);

	// invoke the circle that draws the scatterplot
	// the argument corresponds to the year
	draw_circles(0);
})



// setting the callback function when the slider changes
d3.select("#slider").on("input", render);

// callback function to render the scene when the slider changes
function render() {

	// extracting the value of slider
	var slider_val = d3.select("#slider").property("value");
	
	// rendered_year is the global variable that stores the current year
	// get the rendered_year from the slider (+ converts into integer type)
	rendered_year = +slider_val

	// Call rendering function
	draw_circles(rendered_year)
}



        


function myFunction() {

  
  render()
  	
}



function draw_circles(year) {


	
	

	var a1 = 1800 + year;

	var gdata = [];
  	var hdata = [];
	var adata = [];
	var edata = [];

	var text = svg.selectAll(".text").data(fdata[year]);
                        

	text.enter()
                 .append("text").merge(text)
                 .attr("x", 100)
                 .attr("y", 500)
                 .text(a1)
                 .attr("font-family", "sans-serif")
                 .attr("font-size", "200px")
                 .attr("fill", "aqua").attr("opacity","0.5")
                 .classed("text",true);

	text.exit().remove();

	console.log(a1);
	
	var x = document.getElementById("mySelect").value;
	console.log(x);
	console.log(year);
	//console.log(fdata[year])
	//console.log(fdata[year][0])
	if (x == 'all') {
	    console.log(fdata);	
	    var circle_update = svg.selectAll("circle").data(fdata[year]); 
	    circle_update.enter().append("circle").merge(circle_update)
	    .attr("r",function(d,i){return area(d.population);})	
	    .attr("cx",function(d,i){return xAxis(d.income);})
	    .attr("cy",function(d,i){return yAxis(d.life_exp);})
	    .attr("fill" ,function(d, i ) { return continentColor(d.continent); })
	    circle_update.exit().remove();

	 } else if (x == 'asia') {
	     var i;
	     for (i = 0; i < fdata[year].length; i++) {
		if (fdata[year][i].continent == 'asia') {  
			gdata.push(fdata[year][i])
		}	
	     }
	    console.log(gdata);	
	    var circle_update = svg.selectAll("circle").data(gdata); 
	    circle_update.enter().append("circle").merge(circle_update)
	    .attr("r",function(d,i){return area(d.population);})	
	    .attr("cx",function(d,i){return xAxis(d.income);})
	    .attr("cy",function(d,i){return yAxis(d.life_exp);})
	    .attr("fill" ,function(d, i ) { return continentColor(d.continent); })
	    circle_update.exit().remove();

	 } else if (x == 'africa') {
	     var j;
	     for (j = 0; j < fdata[year].length; j++) {
		if (fdata[year][j].continent == 'africa') {  
			hdata.push(fdata[year][j])
		}	
	     }
	    console.log(hdata);	
	    var circle_update = svg.selectAll("circle").data(hdata); 
	    circle_update.enter().append("circle").merge(circle_update)
	    .attr("r",function(d,i){return area(d.population);})	
	    .attr("cx",function(d,i){return xAxis(d.income);})
	    .attr("cy",function(d,i){return yAxis(d.life_exp);})
	    .attr("fill" ,function(d, i ) { return continentColor(d.continent); })
	    circle_update.exit().remove();
	
	 } else if (x == 'americas') {
	     var k;
	     for (k = 0; k < fdata[year].length; k++) {
		if (fdata[year][k].continent == 'americas') {  
			adata.push(fdata[year][k])
		}	
	     }
	    console.log(adata);	
	    var circle_update = svg.selectAll("circle").data(adata); 
	    circle_update.enter().append("circle").merge(circle_update)
	    .attr("r",function(d,i){return area(d.population);})	
	    .attr("cx",function(d,i){return xAxis(d.income);})
	    .attr("cy",function(d,i){return yAxis(d.life_exp);})
	    .attr("fill" ,function(d, i ) { return continentColor(d.continent); })
	    circle_update.exit().remove();	
	  
	  } else if (x == 'europe') {
	     var m;
	     for (m = 0; m < fdata[year].length; m++) {
		if (fdata[year][m].continent == 'europe') {  
			edata.push(fdata[year][m])
		}	
	     }
	    console.log(edata);	
	    var circle_update = svg.selectAll("circle").data(edata); 
	    circle_update.enter().append("circle").merge(circle_update)
	    .attr("r",function(d,i){return area(d.population);})	
	    .attr("cx",function(d,i){return xAxis(d.income);})
	    .attr("cy",function(d,i){return yAxis(d.life_exp);})
	    .attr("fill" ,function(d, i ) { return continentColor(d.continent); })
	    circle_update.exit().remove();	
	 } 





	
	

	// TODO all your rendering D3 code here
		
    
    	// this variable gets set only through the button 
	// therefore step is called in a loop only when play is pressed
	// step is not called when slider is changed
	if (playing)
        setTimeout(step, 50)
}


// callback function when the button is pressed
function play() {
	
	if (d3.select("button").property("value") == "Play") {
		d3.select("button").text("Pause")
        d3.select("button").property("value", "Pause")
        playing = true
        step()
	}
	else {
		d3.select("button").text("Play")
        d3.select("button").property("value", "Play")
        playing = false
	
	}
}

// callback function when the button is pressed (to play the scene)
function step() {
	
	// At the end of our data, loop back
	rendered_year = (rendered_year < 214) ? rendered_year + 1 : 0
	draw_circles(rendered_year)
}


